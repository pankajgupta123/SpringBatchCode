package com.batch.example.controller;

//package com.batch.SpringBootBatch.controller;

import org.springframework.batch.core.Job;
import org.springframework.batch.core.JobParameters;
import org.springframework.batch.core.JobParametersInvalidException;
import org.springframework.batch.core.launch.JobExecutionNotStoppedException;
import org.springframework.batch.core.launch.JobLauncher;
import org.springframework.batch.core.launch.support.RunIdIncrementer;
import org.springframework.batch.core.repository.JobExecutionAlreadyRunningException;
import org.springframework.batch.core.repository.JobInstanceAlreadyCompleteException;
import org.springframework.batch.core.repository.JobRestartException;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import com.batch.example.model.Product;

import ch.qos.logback.core.status.Status;

@RestController
@RequestMapping("/batch")
public class ProductController {

    @Autowired
    private JobLauncher jobLauncher;

    @Autowired
    private Job job;


    // Post mapping to trigger the batch job
    @PostMapping("/start")
    public ResponseEntity<String> startBatchJob(@RequestBody Product request) throws JobExecutionAlreadyRunningException, JobRestartException, JobInstanceAlreadyCompleteException, JobParametersInvalidException {
        // Use RunIdIncrementer directly to generate job parameters
		JobParameters jobParameters = (JobParameters) ((Object) new RunIdIncrementer());

		// Run the job with generated job parameters
		jobLauncher.run(job, jobParameters);
		String responseMessage = "Product created with name: " + request.getDiscount() + " and age: " + request.getDescription();
		return ResponseEntity.status(HttpStatus.CREATED)
                .body(responseMessage);
    }

     
}
